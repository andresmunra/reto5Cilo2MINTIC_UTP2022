
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class Forma2 extends javax.swing.JFrame {

    public Forma2() {
        initComponents();
        model=(DefaultTableModel) this.jTable1.getModel();
        this.setTitle("INFORMES MINISTERIO DE VIVIENDA");
        this.setLocationRelativeTo(Forma2.this);
        this.setResizable(false);
    }
    DefaultTableModel model;
    String url = "jdbc:sqlite:D://RESPALDO//Desktop//MINTIC//ciclo2//reto5//ProyectosConstruccion.db";
    Connection connect;
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setIcon(new javax.swing.ImageIcon("D:\\RESPALDO\\Desktop\\MINTIC\\ciclo2\\reto5\\banner\\g-banner-100-1637072459548.jpg")); // NOI18N
        jButton1.setText("jButton1");
        jButton1.setSelectedIcon(new javax.swing.ImageIcon("D:\\RESPALDO\\Desktop\\MINTIC\\ciclo2\\reto5\\banner\\g-banner-100-1637072459548.jpg")); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jMenu1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jMenu1.setText("INFORME 1");
        jMenu1.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                jMenu1MenuSelected(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jMenu2.setText("INFORME 2");
        jMenu2.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                jMenu2MenuSelected(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        jMenu3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jMenu3.setText("INFORME 3");
        jMenu3.addMenuListener(new javax.swing.event.MenuListener() {
            public void menuCanceled(javax.swing.event.MenuEvent evt) {
            }
            public void menuDeselected(javax.swing.event.MenuEvent evt) {
            }
            public void menuSelected(javax.swing.event.MenuEvent evt) {
                jMenu3MenuSelected(evt);
            }
        });
        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 681, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu1MenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_jMenu1MenuSelected
        DefaultTableModel consulta1 = new DefaultTableModel();
        consulta1.addColumn("Id Lider");
        consulta1.addColumn("Nombre");
        consulta1.addColumn("Apellido");
        consulta1.addColumn("Ciudad residencia");
        jTable1.setModel(consulta1);
        
        String []datos = new String[4];
        
        try{
            Class.forName("org.sqlite.JDBC");
            connect = DriverManager.getConnection(url);
            Statement leer = connect.createStatement();
            ResultSet resultado= leer.executeQuery("SELECT ID_Lider, Nombre, Primer_Apellido, Ciudad_Residencia FROM Lider l ORDER BY Ciudad_Residencia");
          
            while(resultado.next()){
                datos[0] = resultado.getString(1);
                datos[1] = resultado.getString(2);
                datos[2] = resultado.getString(3);
                datos[3] = resultado.getString(4);
                consulta1.addRow(datos);
                
            }
            jTable1.setModel(consulta1);
        }
        
        catch(ClassNotFoundException | SQLException x){
            JOptionPane.showMessageDialog(null, x.getMessage());
        }
        
    }//GEN-LAST:event_jMenu1MenuSelected

    private void jMenu2MenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_jMenu2MenuSelected
        DefaultTableModel consulta2 = new DefaultTableModel();
        consulta2.addColumn("Id Proyecto");
        consulta2.addColumn("Constructora");
        consulta2.addColumn("No. Habitaciones");
        consulta2.addColumn("Ciudad");
        jTable1.setModel(consulta2);
        
        String []datos2 = new String[4];
        
        try{
            Class.forName("org.sqlite.JDBC");
            connect = DriverManager.getConnection(url);
            Statement leer = connect.createStatement();
            ResultSet resultado2= leer.executeQuery("SELECT ID_Proyecto, Constructora, Numero_Habitaciones, Ciudad FROM Proyecto p WHERE Clasificacion = 'Casa Campestre'AND (Ciudad = 'Baranquilla' OR Ciudad = 'Cartagena' OR Ciudad = 'Santa Marta')");
          
            while(resultado2.next()){
                datos2[0] = resultado2.getString(1);
                datos2[1] = resultado2.getString(2);
                datos2[2] = resultado2.getString(3);
                datos2[3] = resultado2.getString(4);
                consulta2.addRow(datos2);
                
            }
            jTable1.setModel(consulta2);
        }
        
        catch(ClassNotFoundException | SQLException x){
            JOptionPane.showMessageDialog(null, x.getMessage());
        }
        
    }//GEN-LAST:event_jMenu2MenuSelected

    private void jMenu3MenuSelected(javax.swing.event.MenuEvent evt) {//GEN-FIRST:event_jMenu3MenuSelected
        
        DefaultTableModel consulta3 = new DefaultTableModel();
        consulta3.addColumn("Id Compra");
        consulta3.addColumn("Constructora");
        consulta3.addColumn("Banco Vinculado");
        
        jTable1.setModel(consulta3);
        
        String []datos3 = new String[3];
        
        try{
            Class.forName("org.sqlite.JDBC");
            connect = DriverManager.getConnection(url);
            Statement leer = connect.createStatement();
            ResultSet resultado3= leer.executeQuery("SELECT ID_Compra, p.Constructora, p.Banco_Vinculado FROM Compra c INNER JOIN Proyecto p ON c.ID_Proyecto = p.ID_Proyecto WHERE p.Ciudad = 'Salento' AND c.Proveedor = 'Homecenter'");
          
            while(resultado3.next()){
                datos3[0] = resultado3.getString(1);
                datos3[1] = resultado3.getString(2);
                datos3[2] = resultado3.getString(3);
                consulta3.addRow(datos3);
                
            }
            jTable1.setModel(consulta3);
        }
        
        catch(ClassNotFoundException | SQLException x){
            JOptionPane.showMessageDialog(null, x.getMessage());
        }
    }//GEN-LAST:event_jMenu3MenuSelected

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Forma2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
